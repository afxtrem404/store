"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
require('../../../utils/PrototypeFunctions');
var Callback = /*#__PURE__*/function () {
  function Callback(bot, data) {
    var Db = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _classCallCheck(this, Callback);
    this.bot = bot;
    this.data = data;
    this.Db = Db;
  }
  _createClass(Callback, [{
    key: "menuEditarUsuario",
    value: function () {
      var _menuEditarUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var callbackid, _yield$this$Db$user$i, user, restringir, admin, menuEditOptions;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                callbackid = this.data.id;
                _context.next = 3;
                return this.Db.user().informacoes();
              case 3:
                _yield$this$Db$user$i = _context.sent;
                user = _yield$this$Db$user$i.response;
                restringir = user.restrict ? '🚫 Desfazer' : '🚫 Restringir Usuário';
                admin = user.admin ? '👮‍♀️ Desfazer' : '👮‍♀️ Admin';
                menuEditOptions = {
                  message: "<b>Nome:</b> <code>".concat(user.name, "</code>\n<b>Id: </b><code>").concat(user.id, "</code>\n<b>Conta restrita</b>: <code>").concat(user.restrict ? 'sim' : 'não', "</code>\n<b>Admin: </b><code>").concat(user.admin ? 'sim' : 'não', "</code>\n<b>Saldo: </b><code>R$").concat(user.credits, "</code>\n<b>Cart\xF5es: </b><code>").concat(user.shopping.cards, "</code>\n<b>Gifts: </b><code>").concat(user.shopping.gifts, "</code>"),
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: restringir,
                        callback_data: 'restringirUsuario'
                      }], [{
                        text: admin,
                        callback_data: 'promoverUsuario'
                      }], [{
                        text: '⬇️ Cartões do Usuário',
                        callback_data: 'cartoesDoUsuario'
                      }], [{
                        text: '🔙 Voltar',
                        callback_data: 'voltarMenuEdicao'
                      }]]
                    }
                  }
                };
                return _context.abrupt("return", menuEditOptions);
              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
      function menuEditarUsuario() {
        return _menuEditarUsuario.apply(this, arguments);
      }
      return menuEditarUsuario;
    }()
  }, {
    key: "deletarUsuario",
    value: function () {
      var _deletarUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var callbackid, deleteOptions;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                callbackid = this.data.id;
                deleteOptions = {
                  message: "<b>Deseja deletar este usu\xE1rio?</b>",
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '✅ Confirmar',
                        callback_data: 'confirmarDeletarUsuario'
                      }], [{
                        text: '❌ Cancelar',
                        callback_data: 'cancelarDeletar'
                      }]]
                    }
                  }
                };
                return _context2.abrupt("return", deleteOptions);
              case 3:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
      function deletarUsuario() {
        return _deletarUsuario.apply(this, arguments);
      }
      return deletarUsuario;
    }()
  }, {
    key: "cartoesDoUsuario",
    value: function () {
      var _cartoesDoUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var callbackid, getHistoric, _yield$this$Db$user$i2, user;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                callbackid = this.data.id;
                _context3.prev = 1;
                _context3.next = 4;
                return this.Db.user().baixarHistorico();
              case 4:
                getHistoric = _context3.sent;
                _context3.next = 7;
                return this.Db.user().informacoes();
              case 7:
                _yield$this$Db$user$i2 = _context3.sent;
                user = _yield$this$Db$user$i2.response;
                if (!getHistoric.success) {
                  _context3.next = 18;
                  break;
                }
                _context3.next = 12;
                return this.bot.sendChatAction(this.data.from.id, 'upload_document');
              case 12:
                _context3.next = 14;
                return this.bot.sendDocument(this.data.from.id, "".concat(__dirname, "/../../../class/user/users/").concat(user.id, ".txt"), {
                  caption: "Hist\xF3rico de ".concat(user.name)
                });
              case 14:
                this.bot.answerCallbackQuery(callbackid, {
                  text: 'Download bem sucedido.',
                  show_alert: true
                });
                require('fs').unlink("".concat(__dirname, "/../../../class/user/users/").concat(user.id, ".txt"), function (err) {
                  return console.log(err);
                });
                _context3.next = 19;
                break;
              case 18:
                this.bot.answerCallbackQuery(callbackid, 'Ocorreu um erro ao realizar o download de seu histórico.');
              case 19:
                _context3.next = 24;
                break;
              case 21:
                _context3.prev = 21;
                _context3.t0 = _context3["catch"](1);
                this.bot.answerCallbackQuery(callbackid, 'Ocorreu um erro ao realizar o download de seu histórico.');
              case 24:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[1, 21]]);
      }));
      function cartoesDoUsuario() {
        return _cartoesDoUsuario.apply(this, arguments);
      }
      return cartoesDoUsuario;
    }()
  }, {
    key: "confirmarDeletarUsuario",
    value: function () {
      var _confirmarDeletarUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var deleteOptions, deleteUser;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                deleteOptions = {
                  message: "<b>Usu\xE1rio deletado.</b>",
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id
                  }
                };
                _context4.prev = 1;
                _context4.next = 4;
                return this.Db.user().deletarConta();
              case 4:
                deleteUser = _context4.sent;
                this.bot.answerCallbackQuery(this.data.id, {
                  text: 'Usuário deletado com sucesso.',
                  show_alert: true
                });
                return _context4.abrupt("return", deleteOptions);
              case 9:
                _context4.prev = 9;
                _context4.t0 = _context4["catch"](1);
                deleteOptions.message = "<b>Ocorreu uma falha ao exluir este usu\xE1rio.</b>";
                return _context4.abrupt("return", deleteOptions);
              case 13:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[1, 9]]);
      }));
      function confirmarDeletarUsuario() {
        return _confirmarDeletarUsuario.apply(this, arguments);
      }
      return confirmarDeletarUsuario;
    }()
  }, {
    key: "confirmarRestringirUsuario",
    value: function () {
      var _confirmarRestringirUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var restrictUser, restringirUsuario;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                restrictUser = {
                  message: "<b>Usu\xE1rio restringido.</b>",
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id
                  }
                };
                _context5.prev = 1;
                _context5.next = 4;
                return this.Db.user().restringirUsuario();
              case 4:
                restringirUsuario = _context5.sent;
                if (!restringirUsuario.success) {
                  _context5.next = 9;
                  break;
                }
                this.bot.answerCallbackQuery(this.data.id, {
                  text: 'Usuário restringido com sucesso.',
                  show_alert: true
                });
                _context5.next = 11;
                break;
              case 9:
                deleteOptions.message = "<b>Ocorreu uma falha ao restringir este usu\xE1rio.</b>";
                return _context5.abrupt("return", restrictUser);
              case 11:
                return _context5.abrupt("return", restrictUser);
              case 14:
                _context5.prev = 14;
                _context5.t0 = _context5["catch"](1);
                deleteOptions.message = "<b>Ocorreu uma falha ao restringir este usu\xE1rio.</b>";
                return _context5.abrupt("return", restrictUser);
              case 18:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this, [[1, 14]]);
      }));
      function confirmarRestringirUsuario() {
        return _confirmarRestringirUsuario.apply(this, arguments);
      }
      return confirmarRestringirUsuario;
    }()
  }, {
    key: "restringirUsuario",
    value: function () {
      var _restringirUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var _yield$this$Db$user$i3, user, callbackid, deleteOptions;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.Db.user().informacoes();
              case 2:
                _yield$this$Db$user$i3 = _context6.sent;
                user = _yield$this$Db$user$i3.response;
                callbackid = this.data.id;
                if (!user.restrict) {
                  _context6.next = 12;
                  break;
                }
                _context6.next = 8;
                return this.Db.user().reativarConta();
              case 8:
                this.bot.answerCallbackQuery(callbackid, {
                  text: 'Restrinção removida.',
                  show_alert: true
                });
                _context6.next = 11;
                return this.menuEditarUsuario();
              case 11:
                return _context6.abrupt("return", _context6.sent);
              case 12:
                deleteOptions = {
                  message: "<b>Deseja restringir este usu\xE1rio?</b>",
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '✅ Confirmar',
                        callback_data: 'confirmarRestringirUsuario'
                      }], [{
                        text: '❌ Cancelar',
                        callback_data: 'cancelarRestringir'
                      }]]
                    }
                  }
                };
                return _context6.abrupt("return", deleteOptions);
              case 14:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
      function restringirUsuario() {
        return _restringirUsuario.apply(this, arguments);
      }
      return restringirUsuario;
    }()
  }, {
    key: "deleteGift",
    value: function () {
      var _deleteGift = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        var deleteGiftOptions, _this$data$data$split, _this$data$data$split2, gift, delGift;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                deleteGiftOptions = {
                  message: '<b>Gift deletado.</b>',
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id
                  }
                };
                _this$data$data$split = this.data.data.split('_'), _this$data$data$split2 = _slicedToArray(_this$data$data$split, 2), gift = _this$data$data$split2[1];
                _context7.next = 4;
                return this.Db.gift()["delete"](gift);
              case 4:
                delGift = _context7.sent;
                return _context7.abrupt("return", deleteGiftOptions);
              case 6:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));
      function deleteGift() {
        return _deleteGift.apply(this, arguments);
      }
      return deleteGift;
    }()
  }, {
    key: "promoverUsuario",
    value: function () {
      var _promoverUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        var _yield$this$Db$user$i4, user, callbackid, promoteOptions;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.next = 2;
                return this.Db.user().informacoes();
              case 2:
                _yield$this$Db$user$i4 = _context8.sent;
                user = _yield$this$Db$user$i4.response;
                callbackid = this.data.id;
                if (!user.admin) {
                  _context8.next = 12;
                  break;
                }
                _context8.next = 8;
                return this.Db.user().despromoverUsuario();
              case 8:
                this.bot.answerCallbackQuery(callbackid, {
                  text: 'Usuário despromovido.',
                  show_alert: true
                });
                _context8.next = 11;
                return this.menuEditarUsuario();
              case 11:
                return _context8.abrupt("return", _context8.sent);
              case 12:
                promoteOptions = {
                  message: "<b>Deseja promover este usu\xE1rio \xE1 admin?\n\n</b><i>Quando um usu\xE1rio \xE9 promovido \xE0 admin, ele ter\xE1 acesso a todos os comandos da store.</i>",
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '✅ Confirmar',
                        callback_data: 'confirmarPromoverUsuario'
                      }], [{
                        text: '❌ Cancelar',
                        callback_data: 'cancelarPromover'
                      }]]
                    }
                  }
                };
                return _context8.abrupt("return", promoteOptions);
              case 14:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));
      function promoverUsuario() {
        return _promoverUsuario.apply(this, arguments);
      }
      return promoverUsuario;
    }()
  }, {
    key: "confirmarPromoverUsuario",
    value: function () {
      var _confirmarPromoverUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9() {
        var promoteUser, promoverUsuario;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                promoteUser = {
                  message: "<b>Usu\xE1rio promovido \xE0 admin.</b>",
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id
                  }
                };
                _context9.prev = 1;
                _context9.next = 4;
                return this.Db.user().promoverUsuario();
              case 4:
                promoverUsuario = _context9.sent;
                if (!promoverUsuario.success) {
                  _context9.next = 9;
                  break;
                }
                this.bot.answerCallbackQuery(this.data.id, {
                  text: 'Usuário promovido com sucesso.',
                  show_alert: true
                });
                _context9.next = 11;
                break;
              case 9:
                promoteUser.message = "<b>Ocorreu uma falha ao promover este usu\xE1rio.</b>";
                return _context9.abrupt("return", promoteUser);
              case 11:
                return _context9.abrupt("return", promoteUser);
              case 14:
                _context9.prev = 14;
                _context9.t0 = _context9["catch"](1);
                promoteUser.message = "<b>Ocorreu uma falha ao promover este usu\xE1rio.</b>";
                return _context9.abrupt("return", promoteUser);
              case 18:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this, [[1, 14]]);
      }));
      function confirmarPromoverUsuario() {
        return _confirmarPromoverUsuario.apply(this, arguments);
      }
      return confirmarPromoverUsuario;
    }()
  }, {
    key: "menu",
    value: function () {
      var _menu = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10() {
        var _yield$this$Db$user$i5, user, menuOptions;
        return _regeneratorRuntime().wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                _context10.next = 2;
                return this.Db.user().informacoes();
              case 2:
                _yield$this$Db$user$i5 = _context10.sent;
                user = _yield$this$Db$user$i5.response;
                menuOptions = {
                  message: "<b>Nome:</b> <code>".concat(user.name, "</code>\n<b>Id: </b><code>").concat(user.id, "</code>\n<b>Conta restrita</b>: <code>").concat(user.restrict ? 'sim' : 'não', "</code>\n<b>Saldo: </b><code>R$").concat(user.credits, "</code>\n<b>Cart\xF5es: </b><code>").concat(user.shopping.cards, "</code>\n<b>Gifts: </b><code>").concat(user.shopping.gifts, "</code>"),
                  options: {
                    parse_mode: 'html',
                    inline_message_id: this.data.inline_message_id,
                    reply_markup: {
                      inline_keyboard: [[{
                        text: '✏️ Editar usuário',
                        callback_data: 'editarUsuario'
                      }], [{
                        text: '🗑 Deletar usuário',
                        callback_data: 'deletarUsuario'
                      }]]
                    }
                  }
                };
                return _context10.abrupt("return", menuOptions);
              case 6:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this);
      }));
      function menu() {
        return _menu.apply(this, arguments);
      }
      return menu;
    }()
  }, {
    key: "callbackType",
    value: function () {
      var _callbackType = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee23(data) {
        var _this = this;
        var types, _ref, message, options;
        return _regeneratorRuntime().wrap(function _callee23$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                _context23.prev = 0;
                types = {
                  deletarUsuario: function deletarUsuario() {
                    return _this.deletarUsuario();
                  },
                  cartoesDoUsuario: function () {
                    var _cartoesDoUsuario2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11() {
                      return _regeneratorRuntime().wrap(function _callee11$(_context11) {
                        while (1) {
                          switch (_context11.prev = _context11.next) {
                            case 0:
                              return _context11.abrupt("return", _this.cartoesDoUsuario());
                            case 1:
                            case "end":
                              return _context11.stop();
                          }
                        }
                      }, _callee11);
                    }));
                    function cartoesDoUsuario() {
                      return _cartoesDoUsuario2.apply(this, arguments);
                    }
                    return cartoesDoUsuario;
                  }(),
                  editarUsuario: function () {
                    var _editarUsuario = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12() {
                      return _regeneratorRuntime().wrap(function _callee12$(_context12) {
                        while (1) {
                          switch (_context12.prev = _context12.next) {
                            case 0:
                              return _context12.abrupt("return", _this.menuEditarUsuario());
                            case 1:
                            case "end":
                              return _context12.stop();
                          }
                        }
                      }, _callee12);
                    }));
                    function editarUsuario() {
                      return _editarUsuario.apply(this, arguments);
                    }
                    return editarUsuario;
                  }(),
                  restringirUsuario: function () {
                    var _restringirUsuario2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13() {
                      return _regeneratorRuntime().wrap(function _callee13$(_context13) {
                        while (1) {
                          switch (_context13.prev = _context13.next) {
                            case 0:
                              return _context13.abrupt("return", _this.restringirUsuario());
                            case 1:
                            case "end":
                              return _context13.stop();
                          }
                        }
                      }, _callee13);
                    }));
                    function restringirUsuario() {
                      return _restringirUsuario2.apply(this, arguments);
                    }
                    return restringirUsuario;
                  }(),
                  promoverUsuario: function () {
                    var _promoverUsuario2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14() {
                      return _regeneratorRuntime().wrap(function _callee14$(_context14) {
                        while (1) {
                          switch (_context14.prev = _context14.next) {
                            case 0:
                              return _context14.abrupt("return", _this.promoverUsuario());
                            case 1:
                            case "end":
                              return _context14.stop();
                          }
                        }
                      }, _callee14);
                    }));
                    function promoverUsuario() {
                      return _promoverUsuario2.apply(this, arguments);
                    }
                    return promoverUsuario;
                  }(),
                  deleteGift: function () {
                    var _deleteGift2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee15() {
                      return _regeneratorRuntime().wrap(function _callee15$(_context15) {
                        while (1) {
                          switch (_context15.prev = _context15.next) {
                            case 0:
                              return _context15.abrupt("return", _this.deleteGift());
                            case 1:
                            case "end":
                              return _context15.stop();
                          }
                        }
                      }, _callee15);
                    }));
                    function deleteGift() {
                      return _deleteGift2.apply(this, arguments);
                    }
                    return deleteGift;
                  }(),
                  confirmarDeletarUsuario: function () {
                    var _confirmarDeletarUsuario2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee16() {
                      return _regeneratorRuntime().wrap(function _callee16$(_context16) {
                        while (1) {
                          switch (_context16.prev = _context16.next) {
                            case 0:
                              return _context16.abrupt("return", _this.confirmarDeletarUsuario());
                            case 1:
                            case "end":
                              return _context16.stop();
                          }
                        }
                      }, _callee16);
                    }));
                    function confirmarDeletarUsuario() {
                      return _confirmarDeletarUsuario2.apply(this, arguments);
                    }
                    return confirmarDeletarUsuario;
                  }(),
                  confirmarRestringirUsuario: function () {
                    var _confirmarRestringirUsuario2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee17() {
                      return _regeneratorRuntime().wrap(function _callee17$(_context17) {
                        while (1) {
                          switch (_context17.prev = _context17.next) {
                            case 0:
                              return _context17.abrupt("return", _this.confirmarRestringirUsuario());
                            case 1:
                            case "end":
                              return _context17.stop();
                          }
                        }
                      }, _callee17);
                    }));
                    function confirmarRestringirUsuario() {
                      return _confirmarRestringirUsuario2.apply(this, arguments);
                    }
                    return confirmarRestringirUsuario;
                  }(),
                  confirmarPromoverUsuario: function () {
                    var _confirmarPromoverUsuario2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee18() {
                      return _regeneratorRuntime().wrap(function _callee18$(_context18) {
                        while (1) {
                          switch (_context18.prev = _context18.next) {
                            case 0:
                              return _context18.abrupt("return", _this.confirmarPromoverUsuario());
                            case 1:
                            case "end":
                              return _context18.stop();
                          }
                        }
                      }, _callee18);
                    }));
                    function confirmarPromoverUsuario() {
                      return _confirmarPromoverUsuario2.apply(this, arguments);
                    }
                    return confirmarPromoverUsuario;
                  }(),
                  voltarMenuEdicao: function () {
                    var _voltarMenuEdicao = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee19() {
                      return _regeneratorRuntime().wrap(function _callee19$(_context19) {
                        while (1) {
                          switch (_context19.prev = _context19.next) {
                            case 0:
                              return _context19.abrupt("return", _this.menu());
                            case 1:
                            case "end":
                              return _context19.stop();
                          }
                        }
                      }, _callee19);
                    }));
                    function voltarMenuEdicao() {
                      return _voltarMenuEdicao.apply(this, arguments);
                    }
                    return voltarMenuEdicao;
                  }(),
                  cancelarDeletar: function () {
                    var _cancelarDeletar = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee20() {
                      return _regeneratorRuntime().wrap(function _callee20$(_context20) {
                        while (1) {
                          switch (_context20.prev = _context20.next) {
                            case 0:
                              return _context20.abrupt("return", _this.menu());
                            case 1:
                            case "end":
                              return _context20.stop();
                          }
                        }
                      }, _callee20);
                    }));
                    function cancelarDeletar() {
                      return _cancelarDeletar.apply(this, arguments);
                    }
                    return cancelarDeletar;
                  }(),
                  cancelarRestringir: function () {
                    var _cancelarRestringir = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee21() {
                      return _regeneratorRuntime().wrap(function _callee21$(_context21) {
                        while (1) {
                          switch (_context21.prev = _context21.next) {
                            case 0:
                              return _context21.abrupt("return", _this.menuEditarUsuario());
                            case 1:
                            case "end":
                              return _context21.stop();
                          }
                        }
                      }, _callee21);
                    }));
                    function cancelarRestringir() {
                      return _cancelarRestringir.apply(this, arguments);
                    }
                    return cancelarRestringir;
                  }(),
                  cancelarPromover: function () {
                    var _cancelarPromover = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee22() {
                      return _regeneratorRuntime().wrap(function _callee22$(_context22) {
                        while (1) {
                          switch (_context22.prev = _context22.next) {
                            case 0:
                              return _context22.abrupt("return", _this.menuEditarUsuario());
                            case 1:
                            case "end":
                              return _context22.stop();
                          }
                        }
                      }, _callee22);
                    }));
                    function cancelarPromover() {
                      return _cancelarPromover.apply(this, arguments);
                    }
                    return cancelarPromover;
                  }()
                };
                if (!(!types[data] && !data.includes('deleteGift'))) {
                  _context23.next = 4;
                  break;
                }
                return _context23.abrupt("return");
              case 4:
                if (!types[data]) {
                  _context23.next = 10;
                  break;
                }
                _context23.next = 7;
                return types[data]();
              case 7:
                _context23.t0 = _context23.sent;
                _context23.next = 18;
                break;
              case 10:
                if (!data.includes('deleteGift')) {
                  _context23.next = 16;
                  break;
                }
                _context23.next = 13;
                return types.deleteGift();
              case 13:
                _context23.t1 = _context23.sent;
                _context23.next = 17;
                break;
              case 16:
                _context23.t1 = 0;
              case 17:
                _context23.t0 = _context23.t1;
              case 18:
                _ref = _context23.t0;
                message = _ref.message;
                options = _ref.options;
                this.bot.editMessageText(message, options);
                _context23.next = 26;
                break;
              case 24:
                _context23.prev = 24;
                _context23.t2 = _context23["catch"](0);
              case 26:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee23, this, [[0, 24]]);
      }));
      function callbackType(_x) {
        return _callbackType.apply(this, arguments);
      }
      return callbackType;
    }()
  }]);
  return Callback;
}();
module.exports = Callback;