"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
require('../../utils/PrototypeFunctions');
var _require = require('../../utils/checker-bin'),
  getBinData = _require.getBinData;
var request = require('request-promise');
var Checker = require('../../checker');
var binsu = require('../../scrapper/binsu');
var fs = require('fs');
var Card = /*#__PURE__*/function () {
  function Card(db, message) {
    _classCallCheck(this, Card);
    this.Cards = db.Cards;
    this.Level = db.Level;
    this.message = message;
    this.checker = new Checker(db);
  }
  _createClass(Card, [{
    key: "binLookup",
    value: function () {
      var _binLookup = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(card) {
        var message;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(card.length < 6)) {
                  _context.next = 2;
                  break;
                }
                return _context.abrupt("return", {
                  success: false,
                  message: 'bin inválida'
                });
              case 2:
                _context.prev = 2;
                return _context.abrupt("return", {
                  success: true,
                  response: getBinData(card.slice(0, 6))
                });
              case 6:
                _context.prev = 6;
                _context.t0 = _context["catch"](2);
                message = _context.t0.message;
                return _context.abrupt("return", {
                  success: false,
                  response: 'Base bins.su indisponível.\nDebug: ' + message
                });
              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[2, 6]]);
      }));
      function binLookup(_x) {
        return _binLookup.apply(this, arguments);
      }
      return binLookup;
    }()
  }, {
    key: "formatarCartoes",
    value: function () {
      var _formatarCartoes = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var cartoes,
          ignoreAny,
          ggChecker,
          details,
          cards,
          cartoesArrayNaoExistentes,
          cardsNumbers,
          _iterator,
          _step,
          card,
          withoutRepeats,
          between,
          _iterator2,
          _step2,
          _card2,
          number,
          bin,
          exists,
          _e$error,
          _args2 = arguments;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                cartoes = _args2.length > 0 && _args2[0] !== undefined ? _args2[0] : [];
                ignoreAny = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : true;
                ggChecker = _args2.length > 2 && _args2[2] !== undefined ? _args2[2] : false;
                _context2.prev = 3;
                details = {
                  repeats: 0,
                  invalids: 0,
                  exists: 0
                };
                cards = cartoes.split('\n').map(function (card) {
                  return card.match(/\d{15,16}.\d{1,2}.\d{2,4}.\d{3,4}/);
                }).filter(function (match) {
                  if (match !== null && match !== void 0 && match.length) return match;else details.invalids++;
                }).map(function (array) {
                  return array[0];
                }).map(function (card) {
                  return card.replace(/[^0-9]/g, '|');
                }).map(function (card) {
                  return card.trim().split('|');
                }).filter(function (card) {
                  if (card.length === 4 && card[0].luhn()) return card;else details.invalids++;
                }).map(function (card) {
                  var _card = _slicedToArray(card, 4),
                    number = _card[0],
                    month = _card[1],
                    year = _card[2],
                    cvv = _card[3];
                  return {
                    number: number,
                    month: month,
                    year: year,
                    cvv: cvv
                  };
                }).filter(function (set) {
                  return function (c) {
                    return !set.has(c.number) && set.add(c.number) ? true : (details.repeats++, false);
                  };
                }(new Set()));
                if (cards.length) {
                  _context2.next = 8;
                  break;
                }
                return _context2.abrupt("return", {
                  success: false,
                  response: '<b>Nenhum cartão válido encontrado.</b>',
                  debug: "".concat(cards.length, " ").concat(cards.length > 1 ? 'cartões' : 'cartão', " Inv\xE1lido(s)")
                });
              case 8:
                cartoesArrayNaoExistentes = [];
                if (!ggChecker) {
                  _context2.next = 17;
                  break;
                }
                cardsNumbers = [];
                _iterator = _createForOfIteratorHelper(cards);
                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    card = _step.value;
                    cardsNumbers.push(parseInt(card.number.slice(0, 8)));
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }
                withoutRepeats = cardsNumbers.filter(function (element, index) {
                  return cardsNumbers.indexOf(element) === index;
                });
                between = cardsNumbers.length - withoutRepeats.length;
                if (!(between >= 50)) {
                  _context2.next = 17;
                  break;
                }
                return _context2.abrupt("return", {
                  success: false,
                  response: 'credit card generated'
                });
              case 17:
                _iterator2 = _createForOfIteratorHelper(cards);
                _context2.prev = 18;
                _iterator2.s();
              case 20:
                if ((_step2 = _iterator2.n()).done) {
                  _context2.next = 39;
                  break;
                }
                _card2 = _step2.value;
                number = _card2.number;
                _context2.next = 25;
                return this.binLookup(number);
              case 25:
                bin = _context2.sent;
                if (!ignoreAny) {
                  _context2.next = 32;
                  break;
                }
                _context2.next = 29;
                return this.Cards.exists({
                  number: number
                });
              case 29:
                _context2.t0 = _context2.sent;
                _context2.next = 33;
                break;
              case 32:
                _context2.t0 = false;
              case 33:
                exists = _context2.t0;
                if (bin.success) {
                  _context2.next = 36;
                  break;
                }
                return _context2.abrupt("return", {
                  success: false,
                  response: '<b>' + bin.response + '</b>',
                  debug: bin.response
                });
              case 36:
                if (!exists) cartoesArrayNaoExistentes.push({
                  card: _card2,
                  bin: bin.response
                });else details.exists++;
              case 37:
                _context2.next = 20;
                break;
              case 39:
                _context2.next = 44;
                break;
              case 41:
                _context2.prev = 41;
                _context2.t1 = _context2["catch"](18);
                _iterator2.e(_context2.t1);
              case 44:
                _context2.prev = 44;
                _iterator2.f();
                return _context2.finish(44);
              case 47:
                if (cartoesArrayNaoExistentes.length) {
                  _context2.next = 49;
                  break;
                }
                return _context2.abrupt("return", {
                  success: false,
                  response: '<b>☑️ Cartões já adicionados.</b>',
                  debug: "".concat(details.exists, " ").concat(details.exists > 1 ? 'cartões' : 'cartão', " j\xE1 existente(s) no banco de dados.")
                });
              case 49:
                return _context2.abrupt("return", {
                  success: true,
                  response: cartoesArrayNaoExistentes,
                  total: cartoesArrayNaoExistentes.length,
                  details: details
                });
              case 52:
                _context2.prev = 52;
                _context2.t2 = _context2["catch"](3);
                console.log(_context2.t2);
                return _context2.abrupt("return", {
                  success: false,
                  response: '<b>Falha ao adicionar.</b>',
                  debug: (_e$error = _context2.t2 === null || _context2.t2 === void 0 ? void 0 : _context2.t2.error) !== null && _e$error !== void 0 ? _e$error : _context2.t2 === null || _context2.t2 === void 0 ? void 0 : _context2.t2.message
                });
              case 56:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[3, 52], [18, 41, 44, 47]]);
      }));
      function formatarCartoes() {
        return _formatarCartoes.apply(this, arguments);
      }
      return formatarCartoes;
    }()
  }, {
    key: "cartaoRandomico",
    value: function () {
      var _cartaoRandomico = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var totalCards;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.prev = 0;
                _context3.next = 3;
                return this.Cards.find({
                  restrict: false
                });
              case 3:
                totalCards = _context3.sent;
                if (!totalCards.shuffle()[0]) {
                  _context3.next = 8;
                  break;
                }
                return _context3.abrupt("return", {
                  success: true,
                  response: totalCards.shuffle()[0]
                });
              case 8:
                return _context3.abrupt("return", {
                  success: false,
                  response: '<b>Nenhum Cartão disponível</b>'
                });
              case 9:
                _context3.next = 14;
                break;
              case 11:
                _context3.prev = 11;
                _context3.t0 = _context3["catch"](0);
                return _context3.abrupt("return", {
                  success: false,
                  response: _context3.t0.message
                });
              case 14:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[0, 11]]);
      }));
      function cartaoRandomico() {
        return _cartaoRandomico.apply(this, arguments);
      }
      return cartaoRandomico;
    }()
  }, {
    key: "totalQuantidade",
    value: function () {
      var _totalQuantidade = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var totalCards;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return this.Cards.countDocuments({
                  restrict: false
                });
              case 3:
                totalCards = _context4.sent;
                return _context4.abrupt("return", {
                  success: true,
                  response: totalCards
                });
              case 7:
                _context4.prev = 7;
                _context4.t0 = _context4["catch"](0);
                return _context4.abrupt("return", {
                  success: false,
                  response: _context4.t0.message
                });
              case 10:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[0, 7]]);
      }));
      function totalQuantidade() {
        return _totalQuantidade.apply(this, arguments);
      }
      return totalQuantidade;
    }()
  }, {
    key: "checarCartao",
    value: function () {
      var _checarCartao = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                return _context5.abrupt("return", {
                  success: false
                });
              case 1:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }));
      function checarCartao() {
        return _checarCartao.apply(this, arguments);
      }
      return checarCartao;
    }()
  }, {
    key: "total",
    value: function () {
      var _total = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var totalCards;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.prev = 0;
                _context6.next = 3;
                return this.Cards.find({
                  restrict: false
                }).populate('level');
              case 3:
                totalCards = _context6.sent;
                return _context6.abrupt("return", {
                  success: true,
                  response: totalCards
                });
              case 7:
                _context6.prev = 7;
                _context6.t0 = _context6["catch"](0);
                return _context6.abrupt("return", {
                  success: false,
                  response: _context6.t0.message
                });
              case 10:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this, [[0, 7]]);
      }));
      function total() {
        return _total.apply(this, arguments);
      }
      return total;
    }()
  }, {
    key: "cartao",
    value: function () {
      var _cartao2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7(_cartao) {
        var check,
          c,
          response,
          _args7 = arguments;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                check = _args7.length > 1 && _args7[1] !== undefined ? _args7[1] : false;
                _context7.prev = 1;
                _context7.next = 4;
                return this.Cards.findOne({
                  _id: _cartao
                }).populate('level');
              case 4:
                c = _context7.sent;
                if (!check) {
                  _context7.next = 14;
                  break;
                }
                _context7.next = 8;
                return this.checker.check(c);
              case 8:
                response = _context7.sent;
                if (!(response.success && !response.live)) {
                  _context7.next = 13;
                  break;
                }
                return _context7.abrupt("return", {
                  success: false,
                  message: response.message,
                  response: response.card
                });
              case 13:
                return _context7.abrupt("return", {
                  success: true,
                  message: response.message,
                  response: c
                });
              case 14:
                if (!c.restrict) {
                  _context7.next = 18;
                  break;
                }
                return _context7.abrupt("return", {
                  success: false,
                  response: c
                });
              case 18:
                return _context7.abrupt("return", {
                  success: true,
                  response: c
                });
              case 19:
                _context7.next = 24;
                break;
              case 21:
                _context7.prev = 21;
                _context7.t0 = _context7["catch"](1);
                return _context7.abrupt("return", {
                  success: false,
                  response: _context7.t0.message
                });
              case 24:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this, [[1, 21]]);
      }));
      function cartao(_x2) {
        return _cartao2.apply(this, arguments);
      }
      return cartao;
    }()
  }, {
    key: "find",
    value: function () {
      var _find = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8(query) {
        var options,
          _args8 = arguments;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                options = _args8.length > 1 && _args8[1] !== undefined ? _args8[1] : {};
                return _context8.abrupt("return", this.Cards.findOne(query, options).populate('level'));
              case 2:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));
      function find(_x3) {
        return _find.apply(this, arguments);
      }
      return find;
    }()
  }, {
    key: "checar",
    value: function () {
      var _checar = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9(cartao) {
        var c, response;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _context9.prev = 0;
                _context9.next = 3;
                return this.Cards.findOne({
                  _id: cartao
                }).populate('level');
              case 3:
                c = _context9.sent;
                _context9.next = 6;
                return this.checker.check(c, false);
              case 6:
                response = _context9.sent;
                if (!(response.success && !response.live)) {
                  _context9.next = 11;
                  break;
                }
                return _context9.abrupt("return", {
                  success: false,
                  message: response.message,
                  response: response.card
                });
              case 11:
                return _context9.abrupt("return", {
                  success: true,
                  message: response.message,
                  response: c
                });
              case 12:
                _context9.next = 17;
                break;
              case 14:
                _context9.prev = 14;
                _context9.t0 = _context9["catch"](0);
                console.log(_context9.t0.message);
              case 17:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this, [[0, 14]]);
      }));
      function checar(_x4) {
        return _checar.apply(this, arguments);
      }
      return checar;
    }()
  }, {
    key: "mix",
    value: function () {
      var _mix = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10(ignoreAny, value) {
        var check,
          filter,
          totalCards,
          totalCardsFinal,
          cards,
          cardsChecked,
          _iterator3,
          _step3,
          card,
          response,
          _args10 = arguments;
        return _regeneratorRuntime().wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                check = _args10.length > 2 && _args10[2] !== undefined ? _args10[2] : false;
                filter = _args10.length > 3 && _args10[3] !== undefined ? _args10[3] : [];
                _context10.prev = 2;
                _context10.next = 5;
                return this.Cards.find({
                  restrict: false
                }).populate('level');
              case 5:
                totalCards = _context10.sent;
                totalCardsFinal = [];
                if (ignoreAny) {
                  if (filter.length > 0) totalCardsFinal = totalCards.filter(function (card) {
                    return filter.includes(card.level.type);
                  }).shuffle();else totalCardsFinal = totalCards.filter(function (card) {
                    return card.level.type != 'BLACK' && card.level.type != 'INFINITE' && card.level.type != 'BUSINESS' && card.level.type != 'AMERICAN EXPRESS';
                  }).shuffle();
                } else {
                  totalCardsFinal = totalCards.shuffle();
                }
                if (!check) {
                  _context10.next = 40;
                  break;
                }
                cards = [];
                cardsChecked = [];
                _iterator3 = _createForOfIteratorHelper(totalCardsFinal);
                _context10.prev = 12;
                _iterator3.s();
              case 14:
                if ((_step3 = _iterator3.n()).done) {
                  _context10.next = 31;
                  break;
                }
                card = _step3.value;
                _context10.next = 18;
                return this.checker.check(card);
              case 18:
                response = _context10.sent;
                cardsChecked.push(card);
                if (!(response.success && response.live)) {
                  _context10.next = 24;
                  break;
                }
                cards.push(card);
                _context10.next = 27;
                break;
              case 24:
                if (response.success) {
                  _context10.next = 27;
                  break;
                }
                cards = totalCardsFinal.slice(cardsChecked.length, totalCardsFinal.length);
                return _context10.abrupt("break", 31);
              case 27:
                if (!(cards.length == value)) {
                  _context10.next = 29;
                  break;
                }
                return _context10.abrupt("break", 31);
              case 29:
                _context10.next = 14;
                break;
              case 31:
                _context10.next = 36;
                break;
              case 33:
                _context10.prev = 33;
                _context10.t0 = _context10["catch"](12);
                _iterator3.e(_context10.t0);
              case 36:
                _context10.prev = 36;
                _iterator3.f();
                return _context10.finish(36);
              case 39:
                totalCardsFinal = cards;
              case 40:
                if (!(totalCardsFinal.length >= value)) {
                  _context10.next = 44;
                  break;
                }
                return _context10.abrupt("return", {
                  success: true,
                  response: totalCardsFinal.shuffle().slice(0, value--)
                });
              case 44:
                return _context10.abrupt("return", {
                  success: false,
                  response: '<b>Sem estoque disponível para essa mix.</b>'
                });
              case 45:
                _context10.next = 51;
                break;
              case 47:
                _context10.prev = 47;
                _context10.t1 = _context10["catch"](2);
                console.log(_context10.t1);
                return _context10.abrupt("return", {
                  success: false,
                  response: _context10.t1.message
                });
              case 51:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this, [[2, 47], [12, 33, 36, 39]]);
      }));
      function mix(_x5, _x6) {
        return _mix.apply(this, arguments);
      }
      return mix;
    }()
  }, {
    key: "saveMix",
    value: function () {
      var _saveMix = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11(mix, id) {
        var _fs, confirm;
        return _regeneratorRuntime().wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                _context11.prev = 0;
                _fs = require('fs');
                _fs.writeFileSync("".concat(__dirname, "/mix/").concat(id, ".txt"), mix, {
                  flag: 'w'
                });
                confirm = _fs.readFileSync("".concat(__dirname, "/mix/").concat(id, ".txt"), 'utf-8');
                return _context11.abrupt("return", {
                  success: true
                });
              case 7:
                _context11.prev = 7;
                _context11.t0 = _context11["catch"](0);
                console.log(_context11.t0.message);
                return _context11.abrupt("return", {
                  success: false,
                  message: '<b>Ocorreu um erro ao executar este comando.'
                });
              case 11:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11, null, [[0, 7]]);
      }));
      function saveMix(_x7, _x8) {
        return _saveMix.apply(this, arguments);
      }
      return saveMix;
    }()
  }, {
    key: "backup",
    value: function () {
      var _backup = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12(query) {
        var _fs2, cards, cardsString, cardsBackup, confirm;
        return _regeneratorRuntime().wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                _context12.prev = 0;
                _fs2 = require('fs');
                _context12.next = 4;
                return this.Cards.find(query).populate('level');
              case 4:
                cards = _context12.sent;
                cardsString = cards.map(function (card) {
                  return "".concat(card.number, "|").concat(card.month, "|").concat(card.year, "|").concat(card.cvv, "|").concat(card.level.type, "|").concat(card.bin.bank ? card.bin.bank.name : 'Não especificado');
                }).join('\n');
                cardsBackup = "".concat(cardsString.length < 1 ? 'Nada consta' : cardsString);
                _fs2.writeFileSync("".concat(__dirname, "/backup/cards.txt"), cardsBackup, {
                  flag: 'w'
                });
                confirm = _fs2.readFileSync("".concat(__dirname, "/backup/cards.txt"), 'utf-8');
                return _context12.abrupt("return", {
                  success: true
                });
              case 12:
                _context12.prev = 12;
                _context12.t0 = _context12["catch"](0);
                console.log(_context12.t0.message);
                return _context12.abrupt("return", {
                  success: false,
                  message: '<b>Ocorreu um erro ao executar este comando.'
                });
              case 16:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12, this, [[0, 12]]);
      }));
      function backup(_x9) {
        return _backup.apply(this, arguments);
      }
      return backup;
    }()
  }, {
    key: "retirar",
    value: function () {
      var _retirar = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14(query) {
        var _this = this;
        var limit,
          Data,
          _fs3,
          cards,
          removeCards,
          cardsString,
          cardsRetrive,
          confirm,
          _args14 = arguments;
        return _regeneratorRuntime().wrap(function _callee14$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                limit = _args14.length > 1 && _args14[1] !== undefined ? _args14[1] : 10;
                Data = require('../../utils/PreferenceFunctions');
                _context14.prev = 2;
                _fs3 = require('fs');
                _context14.next = 6;
                return this.Cards.find(query).limit(limit).populate('level');
              case 6:
                cards = _context14.sent;
                removeCards = cards.length > 0 ? Promise.all(cards.map( /*#__PURE__*/function () {
                  var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13(card) {
                    return _regeneratorRuntime().wrap(function _callee13$(_context13) {
                      while (1) {
                        switch (_context13.prev = _context13.next) {
                          case 0:
                            _context13.next = 2;
                            return _this.Cards.findOneAndUpdate({
                              number: card.number
                            }, {
                              restrict: true
                            });
                          case 2:
                            return _context13.abrupt("return", _context13.sent);
                          case 3:
                          case "end":
                            return _context13.stop();
                        }
                      }
                    }, _callee13);
                  }));
                  return function (_x11) {
                    return _ref2.apply(this, arguments);
                  };
                }())) : 0;
                cardsString = cards.map(function (card) {
                  var _Data$getData = Data.getData(),
                    name = _Data$getData.name,
                    cpf = _Data$getData.cpf;
                  return "".concat(card.number, "|").concat(card.month, "|").concat(card.year, "|").concat(card.cvv, "|").concat(card.level.type, "|").concat(card.bin.bank ? card.bin.bank.name : 'Não especificado', "|").concat(name, "|").concat(cpf);
                }).join('\n');
                cardsRetrive = "".concat(cardsString.length < 1 ? 'Nada consta' : cardsString);
                _fs3.writeFileSync("".concat(__dirname, "/retirar/cards.txt"), cardsRetrive, {
                  flag: 'w'
                });
                confirm = _fs3.readFileSync("".concat(__dirname, "/retirar/cards.txt"), 'utf-8');
                return _context14.abrupt("return", {
                  success: true,
                  cards: cards
                });
              case 15:
                _context14.prev = 15;
                _context14.t0 = _context14["catch"](2);
                console.log(_context14.t0.message);
                return _context14.abrupt("return", {
                  success: false,
                  message: '<b>Ocorreu um erro ao executar este comando.'
                });
              case 19:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee14, this, [[2, 15]]);
      }));
      function retirar(_x10) {
        return _retirar.apply(this, arguments);
      }
      return retirar;
    }()
  }]);
  return Card;
}();
module.exports = Card;