'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var schema = new Schema({
  name: {
    required: true,
    type: String,
    unique: true
  },
  alerts: {
    type: Object,
    required: true
  },
  statistics: {
    type: Object,
    required: true
  },
  version: {
    required: true,
    type: String
  },
  test_mode: {
    required: true,
    type: Boolean
  },
  settings: {
    required: true,
    type: Object
  },
  about: {
    required: true,
    type: Object
  }
});
module.exports = schema;