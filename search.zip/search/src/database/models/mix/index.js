'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var schema = new Schema({
  mix_id: {
    required: true,
    type: String,
    unique: true
  },
  price: {
    required: true,
    type: String
  },
  description: {
    required: true,
    type: String
  },
  quantity: {
    type: Number,
    required: true
  },
  levels: {
    type: Object,
    required: true
  },
  exchange_time: {
    required: true,
    type: String
  },
  live_percentage: {
    required: true,
    type: Number
  }
});
module.exports = schema;