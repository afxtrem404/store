'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var schema = new Schema({
  txid: {
    required: true,
    unique: true,
    type: String
  },
  loc: {
    type: Object,
    required: true
  },
  payer: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  status: {
    type: String,
    required: true
  },
  value: {
    type: Number,
    required: true
  },
  key: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});
module.exports = schema;